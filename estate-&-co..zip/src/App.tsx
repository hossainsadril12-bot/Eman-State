import React, { useState, useRef } from 'react';
import { motion, AnimatePresence, useScroll, useTransform, useMotionValueEvent } from 'motion/react';
import { 
  ArrowRight, 
  ChevronDown, 
  Phone, 
  Menu,
  X,
  GraduationCap,
  Users,
  Landmark,
  Waves,
  Sunset,
  BellRing,
  ShieldCheck,
  FileCheck,
  Mountain,
  KeyRound,
  Bed,
  TrendingUp,
  Share2,
  Coins
} from 'lucide-react';

/* --- UI COMPONENTS --- */

const Button = ({ 
  children, 
  variant = 'primary', 
  className = '', 
  ...props 
}: { 
  children: React.ReactNode, 
  variant?: 'primary' | 'secondary' | 'outline', 
  className?: string, 
  [key: string]: any 
}) => {
  const base = "px-8 py-4 uppercase tracking-[0.2em] text-xs font-semibold transition-all duration-500 flex items-center gap-2 group cursor-pointer h-14";
  const styles = {
    primary: "bg-warm-gold text-estate-navy hover:bg-white",
    secondary: "text-white hover:text-warm-gold",
    outline: "border border-warm-gold text-warm-gold hover:bg-warm-gold hover:text-estate-navy"
  };

  return (
    <button className={`${base} ${styles[variant === 'primary' || variant === 'secondary' || variant === 'outline' ? variant : 'primary']} ${className}`} {...props}>
      {children}
      {variant === 'secondary' && (
        <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-2" />
      )}
    </button>
  );
};

const Card = ({ title, category, image, price }: any) => (
  <motion.div 
    initial={{ opacity: 0, y: 20 }}
    whileInView={{ opacity: 1, y: 0 }}
    viewport={{ once: true }}
    className="bg-white border border-stone p-8 group cursor-pointer hover:shadow-luxury transition-all duration-700"
  >
    <div className="overflow-hidden mb-6 aspect-[4/5] bg-sand">
      <img 
        src={image} 
        alt={title} 
        className="w-full h-full object-cover grayscale group-hover:grayscale-0 group-hover:scale-110 transition-all duration-1000"
        referrerPolicy="no-referrer"
      />
    </div>
    <p className="font-sans text-[10px] tracking-[0.3em] uppercase text-mist mb-2">{category}</p>
    <h3 className="text-xl mb-4 group-hover:text-warm-gold transition-colors">{title}</h3>
    <div className="flex justify-between items-center pt-4 border-t border-stone/30">
      <span className="font-serif italic text-lg">{price}</span>
      <ArrowRight className="w-5 h-5 text-warm-gold opacity-0 group-hover:opacity-100 -translate-x-4 group-hover:translate-x-0 transition-all duration-500" />
    </div>
  </motion.div>
);

const FAQItem: React.FC<{ question: string, answer: string }> = ({ question, answer }) => {
  const [isOpen, setIsOpen] = useState(false);
  
  return (
    <div className="border-b border-stone py-6">
      <button 
        onClick={() => setIsOpen(!isOpen)}
        className="w-full flex justify-between items-center text-left cursor-pointer"
      >
        <span className="text-lg font-serif tracking-tight">{question}</span>
        <motion.div animate={{ rotate: isOpen ? 180 : 0 }}>
          <ChevronDown className="w-5 h-5 text-warm-gold" />
        </motion.div>
      </button>
      <AnimatePresence>
        {isOpen && (
          <motion.div
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="overflow-hidden"
          >
            <p className="pt-4 text-mist leading-relaxed max-w-2xl">{answer}</p>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};

const faqs = [
  {
    question: "What exactly do I own when I purchase a unit?",
    answer: "You own a specific hotel unit with a registered deed (Saf Kabala) in your name, along with a proportional undivided share in the project land. Both are legally documented and registered under the laws of Bangladesh."
  },
  {
    question: "Will I receive a registered deed in my name?",
    answer: "Yes. Upon full payment, a Unit Ownership Deed (Saf Kabala) is executed and registered under the Registration Act, 1908. Your proportional land share is also mutated and registered in your name."
  },
  {
    question: "How does the profit sharing work?",
    answer: "The hotel operates as a single business. All revenue is pooled, operating costs and a management fee are deducted, and the remaining net profit is distributed to unit owners in proportion to their unit's size relative to the total hotel."
  },
  {
    question: "How and when are profits distributed?",
    answer: "Net profit is distributed to unit owners on a schedule determined by Eiman Estates and communicated to all owners in advance. Complete details of distribution frequency, fee structures, and financial reporting are shared during the onboarding process."
  },
  {
    question: "Can I use my unit personally?",
    answer: "This is your property — and we want you to enjoy it. Unit owners have priority booking rights and discounted usage of their unit and hotel facilities, subject to the hotel's operational schedule and availability."
  },
  {
    question: "Can I sell or transfer my unit?",
    answer: "Your unit is a legally owned asset that can be held, transferred, or inherited. All transfers are subject to the terms of your ownership agreement and require prior written approval from Eiman Estates to ensure operational continuity."
  },
  {
    question: "What is the equity model?",
    answer: "The equity model allows you to introduce additional participants into your unit — family members, business partners, or trusted associates — each holding a documented fractional interest. You remain the primary registered owner. All sub-participation is structured and managed under the oversight of Eiman Estates."
  },
  {
    question: "Who manages the hotel?",
    answer: "Eiman Estates retains full and exclusive operational control of the hotel — from construction through to daily guest experience and financial reporting. Owners are not required to be involved in any aspect of hotel management."
  },
  {
    question: "Who designed the project?",
    answer: "Velora Inani is designed by HuaDu Architecture & Urban Design (HDD), a Shanghai-based firm with projects across Asia, Europe, and the Americas. Structural advisory is led by Prof. Dr. M Shamim Z Bosunia, one of Bangladesh's most prominent structural engineers."
  },
  {
    question: "What stage is the project currently at?",
    answer: "The project land at Inani has been secured and development is underway. A limited number of units are being offered in this first phase."
  },
  {
    question: "When will the hotel be operational?",
    answer: "Construction timelines and projected completion dates are shared with investors during the onboarding process. Eiman Estates provides regular progress updates to all unit owners throughout the development phase."
  },
  {
    question: "Where exactly is the project located?",
    answer: "Velora Inani is located on Marine Drive, Inani, Cox's Bazar — set along an elevated stretch of coastline where the hills meet the sea, away from the main tourist corridor."
  },
  {
    question: "Is my investment legally protected?",
    answer: "Your ownership is structured under the Registration Act, 1908, the Transfer of Property Act, 1882, and the Companies Act, 1994, among other applicable laws of Bangladesh. All terms are documented in a comprehensive ownership agreement."
  },
  {
    question: "What happens to my unit if Eiman Estates faces financial difficulty?",
    answer: "Your unit and proportional land share are registered in your name under the laws of Bangladesh. This ownership survives independently of the Company's status. Your registered deed and land title are your assets — they do not form part of the Company's holdings."
  }
];

/* --- MAIN APP --- */

export default function App() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [earnStep, setEarnStep] = useState(0);
  const heroRef = useRef(null);
  const aboutRef = useRef(null);
  const earnRef = useRef(null);
  
  const { scrollY } = useScroll();
  const { scrollYProgress } = useScroll({
    target: heroRef,
    offset: ["start start", "end start"]
  });

  const { scrollYProgress: aboutScrollProgress } = useScroll({
    target: aboutRef,
    offset: ["start end", "end start"]
  });

  const { scrollYProgress: earnScrollProgress } = useScroll({
    target: earnRef,
    offset: ["start start", "end end"]
  });

  useMotionValueEvent(earnScrollProgress, "change", (latest) => {
    const step = Math.min(3, Math.floor(latest * 4));
    setEarnStep(step);
  });

  const navBg = useTransform(scrollY, [0, 100], ["rgba(255, 255, 255, 0)", "rgba(255, 255, 255, 0.9)"]);
  const navBlur = useTransform(scrollY, [0, 100], ["blur(0px)", "blur(12px)"]);
  const navText = useTransform(scrollY, [0, 100], ["rgba(255, 255, 255, 1)", "rgba(27, 35, 65, 1)"]);
  const navBorder = useTransform(scrollY, [0, 100], ["rgba(255, 255, 255, 0.1)", "rgba(212, 207, 198, 0.3)"]);

  const heroOpacity = useTransform(scrollYProgress, [0, 0.5], [1, 0]);
  const heroScale = useTransform(scrollYProgress, [0, 1], [1, 1.2]);
  const heroTextY = useTransform(scrollYProgress, [0, 0.5], [0, -150]);

  const aboutImageY = useTransform(aboutScrollProgress, [0, 1], [0, 100]);

  return (
    <div className="bg-white min-h-screen">
      {/* SCROLL-REACTIVE NAVIGATION */}
      <motion.nav 
        style={{ backgroundColor: navBg, backdropFilter: navBlur, borderBottomColor: navBorder }}
        className="fixed top-0 w-full z-50 transition-all duration-300"
      >
        <div className="luxury-container h-24 flex items-center justify-between">
          <motion.div 
            style={{ color: navText }}
            className="flex-1 hidden md:flex gap-8 text-[10px] tracking-[0.25em] uppercase font-semibold"
          >
            <a href="#" className="hover:text-warm-gold transition-colors">The Project</a>
            <a href="#" className="hover:text-warm-gold transition-colors">Ownership</a>
          </motion.div>
          
          <motion.div 
            style={{ color: navText }}
            className="flex flex-col items-center"
          >
            <span className="font-serif text-2xl tracking-[0.2em] uppercase">Velora</span>
            <span className="text-[8px] tracking-[0.5em] uppercase text-warm-gold -mt-1 ml-1">Inani</span>
          </motion.div>

          <motion.div 
            style={{ color: navText }}
            className="flex-1 flex justify-end items-center gap-6"
          >
            <div className="hidden md:flex gap-8 text-[10px] tracking-[0.25em] uppercase font-semibold mr-8">
              <a href="#" className="hover:text-warm-gold transition-colors">Location</a>
              <a href="#" className="hover:text-warm-gold transition-colors">Registry</a>
            </div>
            <button className="p-2 cursor-pointer" onClick={() => setIsMenuOpen(true)}>
              <Menu className="w-6 h-6" />
            </button>
          </motion.div>
        </div>
      </motion.nav>

      {/* MOBILE MENU OVERLAY - No changes here */}
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div 
            initial={{ opacity: 0, x: '100%' }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: '100%' }}
            transition={{ type: 'spring', damping: 25, stiffness: 200 }}
            className="fixed inset-0 z-[100] bg-estate-navy text-white p-12 flex flex-col justify-between"
          >
            <div className="flex justify-between items-center text-warm-gold">
              <div className="flex flex-col">
                <span className="font-serif text-xl tracking-[0.2em] uppercase">Velora</span>
                <span className="text-[6px] tracking-[0.5em] uppercase -mt-1">By Eiman Estates</span>
              </div>
              <button onClick={() => setIsMenuOpen(false)} className="p-2 border border-warm-gold/30 rounded-full cursor-pointer">
                <X className="w-6 h-6" />
              </button>
            </div>
            
            <div className="flex flex-col gap-8">
              {['The Residences', 'Private Viewing', 'Investment Atlas', 'Concierge Service', 'Inquire Now'].map((item, i) => (
                <motion.a 
                  key={item}
                  initial={{ opacity: 0, x: 20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.1 * i }}
                  href="#" 
                  className="text-4xl md:text-6xl font-serif hover:italic hover:text-warm-gold transition-all"
                >
                  {item}
                </motion.a>
              ))}
            </div>

            <div className="flex gap-8 text-mist text-xs uppercase tracking-widest border-t border-white/10 pt-8">
              <span>Instagram</span>
              <span>LinkedIn</span>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      <main>
        {/* IMPROVED HERO SECTION */}
        <section ref={heroRef} className="relative h-[200vh] overflow-visible">
          <div className="sticky top-0 h-screen w-full overflow-hidden">
            <motion.div style={{ scale: heroScale }} className="absolute inset-0">
               <video 
                 autoPlay 
                 muted 
                 loop 
                 playsInline
                 className="w-full h-full object-cover" 
               >
                 <source src="https://assets.mixkit.co/videos/preview/mixkit-luxury-resort-with-swimming-pool-and-palm-trees-at-sunset-1224-large.mp4" type="video/mp4" />
               </video>
               {/* 80% Estate Navy Overlay */}
               <div className="absolute inset-0 bg-estate-navy/80" />
            </motion.div>
            
            <div className="luxury-container relative z-10 h-full flex items-center">
              <motion.div
                style={{ opacity: heroOpacity, y: heroTextY }}
                initial={{ opacity: 0, y: 50 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 1.5, ease: [0.16, 1, 0.3, 1] }}
                className="max-w-5xl"
              >
                <div className="flex items-center gap-4 mb-8">
                  <div className="w-12 h-[1px] bg-warm-gold" />
                  <p className="text-warm-gold text-[10px] tracking-[0.5em] uppercase font-bold">
                    Eiman Estates Presents
                  </p>
                </div>
                
                <h1 className="text-white text-5xl md:text-[100px] leading-[0.95] mb-12 tracking-tighter">
                  VELORA INANI <br />
                  <span className="text-warm-gold italic font-normal text-3xl md:text-5xl block mt-4 tracking-normal">Own What Matters.</span>
                </h1>

                <p className="text-mist text-lg md:text-2xl max-w-2xl mb-12 font-serif italic leading-relaxed">
                  A hotel you don’t just stay in — <span className="text-white not-italic font-sans text-sm tracking-[0.2em] uppercase ml-2">you own.</span>
                </p>

                <div className="flex flex-wrap gap-6">
                  <Button variant="outline">Explore the Project</Button>
                </div>
              </motion.div>
            </div>

            <motion.div 
              style={{ opacity: heroOpacity }}
              animate={{ y: [0, 10, 0] }}
              transition={{ repeat: Infinity, duration: 2 }}
              className="absolute bottom-12 left-12 text-warm-gold flex flex-col items-start gap-4"
            >
              <span className="text-[8px] tracking-[0.4em] uppercase writing-mode-vertical">Discovery</span>
              <div className="w-[1px] h-16 bg-warm-gold/20 relative">
                <motion.div 
                  animate={{ height: ['0%', '100%'], top: ['100%', '0%'] }}
                  transition={{ repeat: Infinity, duration: 3, ease: 'easeInOut' }}
                  className="w-full bg-warm-gold absolute"
                />
              </div>
            </motion.div>
          </div>
        </section>

        {/* ABOUT SECTION → Seamless + Editorial Flow */}
        <section ref={aboutRef} className="relative z-20 bg-white -mt-[100vh] section-padding pt-[160px] pb-[160px] overflow-hidden">
          <div className="luxury-container grid md:grid-cols-2 gap-24 items-center">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-100px" }}
              transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
              className="space-y-10 max-w-[600px]"
            >
              <div className="space-y-4">
                <p className="text-mist text-[10px] tracking-[0.4em] uppercase font-bold">
                  ABOUT THE PROJECT
                </p>
                <h2 className="text-4xl lg:text-7xl text-estate-navy tracking-tight leading-[1.1]">
                   About <br/>
                  <span className="italic text-warm-gold">Velora Inani</span>
                </h2>
              </div>
              
              <div className="space-y-8">
                <p className="text-slate text-xl leading-relaxed font-light">
                  Velora Inani is a fully managed hotel development set along a quiet, elevated stretch of Inani's coastline where the hills meet the sea — away from the congestion of the main tourist corridor.
                </p>
                
                <p className="text-warm-gold text-lg font-serif italic border-l-2 border-warm-gold/30 pl-8">
                  A beachfront asset on Marine Drive, Cox's Bazar, designed for long-term ownership. A limited number of units are being offered in this first phase.
                </p>

                <p className="text-mist text-base leading-relaxed">
                  The project is designed by <span className="text-estate-navy font-semibold">HuaDu Architecture & Urban Design (HDD)</span>, a Shanghai-based firm whose portfolio spans three continents, including the Beijing Sunrise East Kempinski Hotel. HDD is responsible for the architectural, structural, MEP, and interior design of Velora Inani.
                </p>
              </div>

              <div className="pt-8">
                <Button variant="secondary">The Vision Dossier</Button>
              </div>
            </motion.div>

            <div className="relative">
              <motion.div
                style={{ y: aboutImageY }}
                className="aspect-[3/4] bg-sand overflow-hidden border border-stone/30 p-2 shadow-luxury shrink-0"
              >
                <img 
                  src="https://images.unsplash.com/photo-1600607687940-4e5a994239b7?auto=format&fit=crop&q=80&w=1200" 
                  className="w-full h-full object-cover grayscale hover:grayscale-0 transition-all duration-1000 scale-110" 
                  alt="About Velora"
                  referrerPolicy="no-referrer"
                />
              </motion.div>
              
              {/* Soft fade elements for editorial feel */}
              <div className="absolute -top-12 -left-12 w-24 h-24 border-t border-l border-warm-gold/20" />
              <div className="absolute -bottom-12 -right-12 w-24 h-24 border-b border-r border-warm-gold/20" />
            </div>
          </div>
        </section>

        {/* STRUCTURAL ADVISORY → Leading Authority Section */}
        <section className="section-padding bg-[#F9F7F4] relative overflow-hidden">
          {/* Architectural Watermark background */}
          <div className="absolute right-0 top-0 w-1/2 h-full opacity-[0.03] pointer-events-none">
            <img 
              src="https://images.unsplash.com/photo-1545558014-8692077e9b5c?auto=format&fit=crop&q=80&w=1200" 
              className="w-full h-full object-contain object-right"
              alt="Bridge Blueprint"
            />
          </div>

          <div className="luxury-container grid lg:grid-cols-12 gap-16 items-center">
            {/* Portrait Column */}
            <motion.div 
              initial={{ opacity: 0, x: -30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="lg:col-span-5 relative"
            >
              <div className="aspect-[4/5] bg-sand overflow-hidden shadow-2xl relative z-10">
                <img 
                  src="https://images.unsplash.com/photo-1556157382-97dee2dcb96a?auto=format&fit=crop&q=80&w=800" 
                  className="w-full h-full object-cover grayscale brightness-90 hover:grayscale-0 transition-all duration-1000"
                  alt="Prof. Dr. M Shamim Z Bosunia"
                  referrerPolicy="no-referrer"
                />
              </div>
              {/* Decorative Frame */}
              <div className="absolute -top-6 -left-6 w-full h-full border border-warm-gold/20 -z-0" />
            </motion.div>

            {/* Content Column */}
            <motion.div 
              initial={{ opacity: 0, x: 30 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              className="lg:col-span-7 space-y-10"
            >
              <div className="space-y-6">
                <div className="space-y-4">
                  <p className="text-estate-navy text-[10px] tracking-[0.4em] uppercase font-bold opacity-80">
                    STRUCTURAL ADVISORY IS LED BY
                  </p>
                  <div className="w-16 h-[2px] bg-warm-gold" />
                </div>
                <h2 className="text-4xl lg:text-5xl text-estate-navy font-serif leading-tight">
                  Prof. Dr. M <br />
                  <span className="italic">Shamim Z Bosunia</span>
                </h2>
                <p className="text-slate text-lg leading-relaxed max-w-2xl font-light">
                  A distinguished leader in the field of civil engineering, whose vision and expertise continue to shape some of the nation's most iconic infrastructure projects.
                </p>
              </div>

              <div className="space-y-8 pt-6 border-t border-stone/30 max-w-xl">
                {[
                  { 
                    label: 'Former Dean', 
                    sub: 'Faculty of Civil Engineering, BUET',
                    icon: <GraduationCap className="w-6 h-6" /> 
                  },
                  { 
                    label: 'President', 
                    sub: 'Bangladesh Association of Consulting Engineers (BACE)',
                    icon: <Users className="w-6 h-6" /> 
                  },
                  { 
                    label: 'Chairman', 
                    sub: 'Government-appointed Panel of Experts for Padma Multipurpose Bridge and Karnaphuli Tunnel',
                    icon: <Landmark className="w-6 h-6" /> 
                  }
                ].map((item, idx) => (
                  <motion.div 
                    key={item.label}
                    initial={{ opacity: 0, y: 10 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ delay: idx * 0.1 }}
                    className="flex gap-6 items-start group"
                  >
                    <div className="p-4 bg-estate-navy text-warm-gold rounded-full transition-transform duration-500 group-hover:scale-110 shrink-0">
                      {item.icon}
                    </div>
                    <div>
                      <h4 className="text-estate-navy font-bold text-lg leading-tight">{item.label}</h4>
                      <p className="text-mist text-sm mt-2 leading-relaxed">{item.sub}</p>
                    </div>
                  </motion.div>
                ))}
              </div>
            </motion.div>
          </div>
        </section>

        {/* BREATHER → Emotional Reset Moment */}
        <section className="h-[80vh] flex items-center justify-center overflow-hidden bg-sand relative border-y border-stone/20">
          <motion.div 
            className="absolute inset-0 opacity-20 pointer-events-none"
            animate={{ 
              background: [
                "radial-gradient(circle at 20% 30%, #C9A96E 0%, transparent 70%)",
                "radial-gradient(circle at 80% 70%, #C9A96E 0%, transparent 70%)",
                "radial-gradient(circle at 20% 30%, #C9A96E 0%, transparent 70%)",
              ]
            }}
            transition={{ duration: 15, repeat: Infinity, ease: "linear" }}
          />
          
          <div className="luxury-container text-center relative z-10">
            <motion.div
              initial={{ opacity: 0, scale: 1.1 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: false, amount: 0.5 }}
              transition={{ duration: 2, ease: [0.16, 1, 0.3, 1] }}
            >
              <h2 className="text-2xl md:text-5xl font-serif text-estate-navy lowercase tracking-tight leading-relaxed italic max-w-4xl mx-auto">
                "A decision like this <span className="text-warm-gold not-italic font-sans text-sm tracking-[0.3em] uppercase align-middle mx-4">deserves</span> clarity, not pressure."
              </h2>
              <motion.div 
                initial={{ width: 0 }}
                whileInView={{ width: "100px" }}
                transition={{ delay: 1, duration: 1.5 }}
                className="h-[1px] bg-warm-gold mx-auto mt-12"
              />
            </motion.div>
          </div>
        </section>

        {/* OWNERSHIP MODEL → Structured + Scannable */}
        <section className="section-padding bg-white relative overflow-hidden">
          {/* Subtle floral/architectural background element */}
          <div className="absolute left-0 bottom-0 w-64 h-64 border-r border-t border-warm-gold/10 -rotate-12 translate-y-1/2 -translate-x-1/2 pointer-events-none" />

          <div className="luxury-container">
            {/* Header: Centered first */}
            <div className="mb-24 space-y-6">
              <span className="text-warm-gold text-[10px] tracking-[0.4em] uppercase font-bold">4A — The Asset</span>
              <h2 className="text-4xl lg:text-8xl text-estate-navy tracking-tighter leading-[0.9]">
                What You <br />
                <span className="italic text-warm-gold">Own.</span>
              </h2>
            </div>

            <div className="space-y-32">
              {/* Introduction Text */}
              <motion.div 
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                className="max-w-4xl border-l-[3px] border-warm-gold pl-10"
              >
                <p className="text-estate-navy text-2xl md:text-5xl font-serif leading-tight">
                  When you invest in Velora Inani, you acquire a specific, <span className="text-warm-gold">identifiable</span> hotel unit — <span className="italic opacity-60">not a share in a fund, not a promise on paper.</span>
                </p>
              </motion.div>

              {/* Redesigned content blocks: Layered Bento-Editorial Style */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                {[
                  {
                    title: "A Registered Deed",
                    sub: "(Saf Kabala)",
                    summary: "The Registration Act, 1908",
                    icon: <FileCheck className="w-8 h-8" />,
                    description: "Full legal execution in your name, ensuring absolute and indefinite ownership of your specific unit. This ensures permanence and liquidity for your investment portfolio."
                  },
                  {
                    title: "Land Share",
                    sub: "Ownership",
                    summary: "Undivided interest in land",
                    icon: <Mountain className="w-8 h-8" />,
                    description: "Mutated and registered in your name, ensuring your asset is anchored by the permanent security of physical land ownership in a premium coastal location."
                  },
                  {
                    title: "Legal Title",
                    sub: "Full Rights",
                    summary: "Hold, Transfer, Inherit",
                    icon: <KeyRound className="w-8 h-8" />,
                    description: "Full title rights to your asset, allowing you to hold, transfer, or bequeath it subject to the terms of your ownership agreement, just like any other private residence."
                  }
                ].map((item, idx) => (
                  <motion.div 
                    key={item.title}
                    initial={{ opacity: 0, y: 40 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    transition={{ delay: idx * 0.15, duration: 1 }}
                    viewport={{ once: true }}
                    className="flex flex-col h-full bg-[#FBF9F6] border border-stone/20 p-10 lg:p-12 hover:border-warm-gold transition-all duration-700 hover:shadow-2xl hover:shadow-warm-gold/5 group"
                  >
                    <div className="flex justify-between items-start mb-12">
                      <div className="p-4 bg-white border border-stone/10 text-warm-gold shadow-sm group-hover:bg-estate-navy group-hover:text-white transition-all duration-500">
                        {item.icon}
                      </div>
                      <span className="font-serif text-5xl italic text-stone/20 group-hover:text-warm-gold/20 transition-colors">0{idx +1}</span>
                    </div>

                    <div className="space-y-4 mb-8">
                      <h3 className="text-3xl text-estate-navy font-bold leading-none uppercase tracking-tighter">
                        {item.title} <br />
                        <span className="text-warm-gold italic font-serif normal-case tracking-normal">{item.sub}</span>
                      </h3>
                    </div>

                    <div className="bg-white p-4 border-l-2 border-warm-gold mb-8">
                       <p className="text-estate-navy font-bold text-[9px] tracking-widest uppercase">
                        → {item.summary}
                      </p>
                    </div>

                    <p className="text-mist text-base leading-relaxed font-light flex-grow">
                      {item.description}
                    </p>
                    
                    <div className="mt-12 pt-8 border-t border-stone/20 overflow-hidden">
                      <motion.div 
                        initial={{ x: "-100%" }}
                        whileInView={{ x: 0 }}
                        transition={{ duration: 1.5, ease: "circOut" }}
                        className="h-[1px] bg-warm-gold w-full"
                      />
                    </div>
                  </motion.div>
                ))}
              </div>

              {/* Closing statement block */}
              <motion.div 
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                viewport={{ once: true }}
                className="pt-12"
              >
                <div className="bg-estate-navy text-white p-12 lg:p-24 relative overflow-hidden group">
                  {/* Geometric floating element */}
                  <div className="absolute top-0 right-0 w-96 h-96 bg-warm-gold/[0.03] -translate-y-1/2 translate-x-1/2 rotate-45 border border-white/5 pointer-events-none" />
                  
                  <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-16 relative z-10">
                    <p className="font-serif italic text-3xl lg:text-5xl leading-[1.2] max-w-3xl">
                      "You own the asset. <span className="text-warm-gold not-italic">Eiman Estates runs the business</span> to protect the value of every owner's investment."
                    </p>
                    
                    <div className="flex flex-col sm:flex-row gap-8 items-center lg:shrink-0">
                      <Button className="!bg-warm-gold !text-estate-navy border-none h-16 px-10 text-sm font-bold uppercase tracking-widest hover:scale-105 transition-all">Request Legal Dossier</Button>
                      <p className="text-mist text-[10px] tracking-[0.2em] uppercase font-bold opacity-60 text-center lg:text-left">Verified Ownership <br /> Structure</p>
                    </div>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* HOW YOU EARN → Apple-Style Sticky Scroll Storytelling */}
        <section ref={earnRef} className="relative h-[400vh] bg-white">
          <div className="sticky top-0 h-screen w-full flex items-center overflow-hidden">
            {/* Background Watermarks */}
            <div className="absolute inset-0 pointer-events-none opacity-[0.03]">
              <Landmark className="absolute top-20 left-20 w-96 h-96 -rotate-12" />
              <div className="absolute bottom-40 right-20 w-[500px] h-[500px] border border-estate-navy rounded-full" />
            </div>

            <div className="luxury-container h-full grid lg:grid-cols-2 gap-24 items-center">
              {/* Left Side: Large Portrait Image (States) */}
              <div className="relative hidden lg:block h-[70vh] aspect-[4/5] overflow-hidden rounded-sm shadow-2xl bg-sand">
                <AnimatePresence mode="wait">
                  {earnStep === 0 && (
                    <motion.img 
                      key="img0"
                      initial={{ opacity: 0, scale: 1.1 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      transition={{ duration: 1.5 }}
                      src="https://images.unsplash.com/photo-1542314831-068cd1dbfeeb?auto=format&fit=crop&q=80&w=1200" 
                      className="absolute inset-0 w-full h-full object-cover"
                      alt="Income Generation"
                    />
                  )}
                  {earnStep === 1 && (
                    <motion.img 
                      key="img1"
                      initial={{ opacity: 0, scale: 1.1 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      transition={{ duration: 1.5 }}
                      src="https://images.unsplash.com/photo-1571896349842-33c89424de2d?auto=format&fit=crop&q=80&w=1200" 
                      className="absolute inset-0 w-full h-full object-cover"
                      alt="Revenue Pool"
                    />
                  )}
                  {earnStep === 2 && (
                    <motion.img 
                      key="img2"
                      initial={{ opacity: 0, scale: 1.1 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      transition={{ duration: 1.5 }}
                      src="https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&q=80&w=1200" 
                      className="absolute inset-0 w-full h-full object-cover"
                      alt="Operations"
                    />
                  )}
                  {earnStep === 3 && (
                    <motion.img 
                      key="img3"
                      initial={{ opacity: 0, scale: 1.1 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      transition={{ duration: 1.5 }}
                      src="https://images.unsplash.com/photo-1613977257363-707ba9348227?auto=format&fit=crop&q=80&w=1200" 
                      className="absolute inset-0 w-full h-full object-cover"
                      alt="Yield Distribution"
                    />
                  )}
                </AnimatePresence>
                <div className="absolute inset-0 border border-black/5" />
                {/* Floating Label */}
                <div className="absolute bottom-10 left-10 z-20 bg-white/90 backdrop-blur-md px-6 py-4 shadow-xl">
                  <span className="text-warm-gold text-[10px] tracking-[0.4em] uppercase font-bold">0{earnStep + 1}</span>
                </div>
              </div>

              {/* Right Side: Narrative Content Panels */}
              <div className="relative h-[80vh] flex flex-col justify-center">
                <div className="mb-20">
                  <p className="text-warm-gold text-[10px] tracking-[0.5em] uppercase font-bold mb-4">Income</p>
                  <h2 className="text-5xl md:text-7xl text-estate-navy tracking-tight leading-none mb-8 font-serif">
                    How you <span className="italic">earn</span>
                  </h2>
                  <div className="space-y-4">
                    <p className="text-warm-gold text-xs tracking-[0.3em] font-bold uppercase italic inline-block border-b border-warm-gold/20 pb-2">
                      Simple. Structured. Passive.
                    </p>
                    <p className="text-mist text-lg leading-relaxed opacity-80 max-w-lg">
                      Your unit doesn't sit idle. It earns — as part of a collectively operated hotel where every unit contributes to and benefits from the property's total performance.
                    </p>
                  </div>
                </div>

                <div className="relative h-[400px]">
                  <AnimatePresence mode="wait">
                    <motion.div 
                      key={earnStep}
                      initial={{ opacity: 0, y: 40 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -40 }}
                      transition={{ duration: 1, ease: [0.16, 1, 0.3, 1] }}
                      className="absolute inset-0 space-y-6"
                    >
                      <span className="text-estate-navy/30 text-5xl font-serif italic">Step 0{earnStep + 1}</span>
                      <h4 className="text-3xl md:text-5xl text-estate-navy font-bold leading-tight">
                        {[
                          "The hotel generates income",
                          "All revenue is pooled",
                          "Operating costs and a management fee are deducted",
                          "Net profit is distributed"
                        ][earnStep]}
                      </h4>
                      <p className="text-mist text-xl leading-relaxed font-light">
                        {[
                          "from rooms, food and beverage, events, and all guest services",
                          "across the property",
                          "", // Empty for the third point based on provided content structure
                          "to unit owners in proportion to their unit's size relative to the total hotel"
                        ][earnStep]}
                      </p>
                      
                      {/* Interactive Progress Bar */}
                      <div className="pt-12">
                        <div className="flex gap-4">
                          {[0, 1, 2, 3].map((s) => (
                            <div 
                              key={s} 
                              className={`h-1 flex-1 transition-all duration-700 ${s <= earnStep ? 'bg-warm-gold' : 'bg-stone/20'}`} 
                            />
                          ))}
                        </div>
                      </div>
                    </motion.div>
                  </AnimatePresence>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* THE EQUITY MODEL → Cinematic Immersive Section */}
        <section className="relative h-screen min-h-[700px] flex items-center overflow-hidden bg-estate-navy">
          {/* Background Image with Parallax-like scale effect */}
          <motion.div 
            initial={{ scale: 1.1 }}
            whileInView={{ scale: 1 }}
            transition={{ duration: 10, ease: "linear" }}
            className="absolute inset-0 z-0"
          >
            <img 
              src="https://images.unsplash.com/photo-1507525428034-b723cf961d3e?auto=format&fit=crop&q=80&w=2000" 
              className="w-full h-full object-cover opacity-60 saturate-[0.8]"
              alt="Aerial Coastal View"
              referrerPolicy="no-referrer"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-estate-navy via-transparent to-estate-navy/20" />
          </motion.div>

          <div className="luxury-container relative z-10">
            <div className="grid lg:grid-cols-2 gap-24 items-end">
              <motion.div
                initial={{ opacity: 0, x: -50 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 1.5, ease: [0.16, 1, 0.3, 1] }}
                className="space-y-12"
              >
                <div className="space-y-4">
                  <span className="text-warm-gold text-[10px] tracking-[0.5em] uppercase font-bold block">The Equity Model</span>
                  <h2 className="text-5xl md:text-8xl text-white tracking-tighter leading-[0.9] font-serif">
                    Ownership <br />
                    <span className="italic">You Can Share</span>
                  </h2>
                </div>

                <div className="h-[1px] w-24 bg-warm-gold" />

                <p className="text-white text-xl md:text-2xl font-serif max-w-xl leading-relaxed italic">
                  "Velora Inani offers something most hotel developments do not — a built-in equity model that lets you bring others into your investment."
                </p>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 1.5, delay: 0.2, ease: [0.16, 1, 0.3, 1] }}
                className="space-y-8 lg:pb-12"
              >
                <p className="text-white/80 text-lg leading-relaxed max-w-lg">
                  As a primary unit owner, you can introduce additional participants — family, partners, or trusted associates — each holding a documented fractional interest. You remain the registered owner. All participation is structured, documented, and managed under the oversight of Eiman Estates.
                </p>
                
                <p className="text-warm-gold text-lg font-serif italic border-l border-warm-gold pl-6">
                  This makes Velora Inani not just a personal investment, but one you can share on your terms.
                </p>

                <div className="pt-8">
                  <button className="group relative flex items-center gap-4 text-white uppercase text-[10px] tracking-[0.4em] font-bold">
                    <span>Explore Structure</span>
                    <div className="w-12 h-[1px] bg-white group-hover:w-20 transition-all duration-500" />
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* ABOUT EIMAN ESTATES → Trust Anchor */}
        <section className="section-padding bg-sand">
          <div className="luxury-container">
            <div className="grid lg:grid-cols-2 gap-24 items-center">
              <motion.div
                initial={{ opacity: 0, x: -30 }}
                whileInView={{ opacity: 1, x: 0 }}
                transition={{ duration: 1.2, ease: [0.16, 1, 0.3, 1] }}
                viewport={{ once: true }}
                className="space-y-12"
              >
                <div className="space-y-4">
                  <span className="text-warm-gold text-[10px] tracking-[0.5em] uppercase font-bold">About Eiman Estates</span>
                  <h2 className="text-4xl lg:text-6xl text-estate-navy tracking-tight leading-[1.1] font-serif">
                    Built To The Same Standard <br />
                    <span className="italic">It Is Managed.</span>
                  </h2>
                </div>

                <div className="space-y-8">
                  <p className="text-warm-gold text-xl lg:text-2xl font-serif italic leading-relaxed border-l-2 border-warm-gold pl-6">
                    "Velora Inani is the first development by Eiman Estates — founded by a group of entrepreneurs with experience across real estate development, healthcare operations, manufacturing, and technology, including hospitality management software."
                  </p>
                  
                  <div className="space-y-6 text-mist text-base lg:text-lg leading-relaxed">
                    <p>
                      When you invest in Velora Inani, you don't manage tenants. You don't coordinate maintenance. You don't negotiate rates or handle compliance. That's our job — and it's the only job we do.
                    </p>
                    <p>
                      Eiman Estates holds full responsibility for three things: building the asset right, operating it professionally, and reporting to you transparently.
                    </p>
                    <p>
                      The project is designed by an international team led by HDD Shanghai and advised by Prof. Dr. M Shamim Z Bosunia — reflecting the same standard of rigour that defines how we build and how we operate.
                    </p>
                  </div>

                  <div className="pt-8">
                    <button className="group relative flex items-center gap-4 text-estate-navy uppercase text-[10px] tracking-[0.4em] font-bold">
                      <span>Our Heritage</span>
                      <div className="w-12 h-[1px] bg-estate-navy group-hover:w-20 transition-all duration-500" />
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              </motion.div>

              <motion.div
                initial={{ opacity: 0, y: 50 }}
                whileInView={{ opacity: 1, y: 0 }}
                transition={{ duration: 1.5, ease: [0.16, 1, 0.3, 1] }}
                viewport={{ once: true }}
                className="relative lg:pl-12"
              >
                <div className="aspect-[4/5] relative overflow-hidden shadow-[0_20px_50px_rgba(27,35,65,0.1)] group">
                  <img 
                    src="https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&q=80&w=1200"
                    alt="Eiman Estates Architecture"
                    className="absolute inset-0 w-full h-full object-cover grayscale transition-all duration-1000 group-hover:scale-105 group-hover:grayscale-0"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 ring-1 ring-inset ring-white/30 m-6 pointer-events-none" />
                </div>
                
                {/* Decorative Element */}
                <div className="absolute -bottom-10 -left-10 w-48 h-48 border border-warm-gold/20 rounded-full flex items-center justify-center pointer-events-none hidden md:flex">
                  <div className="w-32 h-32 border border-warm-gold/10 rounded-full" />
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* SECTION FAQ */}
        <section className="section-padding bg-white relative">
          <div className="luxury-container">
            <div className="grid lg:grid-cols-12 gap-16">
              {/* FAQ Header */}
              <div className="lg:col-span-4 space-y-6">
                <span className="text-warm-gold text-[10px] tracking-[0.5em] uppercase font-bold">Frequently Asked Questions</span>
                <h2 className="text-4xl md:text-5xl text-estate-navy tracking-tight leading-none font-serif">
                  Clear, <br />
                  <span className="italic text-warm-gold">transparent</span> answers.
                </h2>
                <p className="text-mist text-lg leading-relaxed pt-6">
                  We believe absolute clarity is the foundation of trust. Explore the essential details of ownership and operation.
                </p>
                <div className="pt-8 hidden lg:block">
                  <div className="w-24 h-[1px] bg-warm-gold/30" />
                </div>
              </div>

              {/* FAQ Accordion */}
              <div className="lg:col-span-8">
                <div className="border-t border-stone">
                  {faqs.map((faq, index) => (
                    <FAQItem key={index} question={faq.question} answer={faq.answer} />
                  ))}
                </div>
              </div>
            </div>
          </div>
        </section>


        {/* SECTION 8 — CONTACT → Conversion Engine */}
        <section className="section-padding bg-estate-navy relative">
          <div className="luxury-container">
            <div className="text-center mb-16 space-y-8">
              <div className="space-y-6">
                <span className="text-warm-gold text-[10px] tracking-[0.5em] uppercase font-bold">Contact</span>
                <h2 className="text-4xl md:text-6xl text-white tracking-tight leading-none font-serif">
                  A Considered <br />
                  <span className="italic text-warm-gold">Entry.</span>
                </h2>
              </div>
              <p className="text-mist text-lg max-w-2xl mx-auto leading-relaxed">
                When you're ready to learn more, we're ready to walk you through everything — clearly and at your pace.
              </p>
              
              <div className="pt-4 pb-8 flex justify-center">
                <a 
                  href="#" 
                  className="bg-[#25D366] text-white px-10 py-5 rounded-full shadow-[0_0_30px_rgba(37,211,102,0.4)] hover:shadow-[0_0_50px_rgba(37,211,102,0.6)] hover:scale-105 transition-all duration-500 flex items-center gap-4 animate-pulse inline-flex"
                >
                  <svg 
                    viewBox="0 0 24 24" 
                    width="24" 
                    height="24" 
                    stroke="currentColor" 
                    strokeWidth="2" 
                    fill="none" 
                    strokeLinecap="round" 
                    strokeLinejoin="round"
                    className="w-8 h-8"
                  >
                    <path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z" />
                  </svg>
                  <span className="text-base font-bold tracking-[0.2em] uppercase">WhatsApp Us Directly</span>
                </a>
              </div>
            </div>

            <div className="max-w-2xl mx-auto space-y-12">
              <div className="bg-white p-12 lg:p-16 shadow-2xl relative z-10">
                <form className="space-y-6">
                  <div className="w-full relative">
                    <input 
                      type="text" 
                      placeholder="Your Name" 
                      className="w-full bg-transparent border-b border-stone/30 py-4 text-estate-navy text-lg outline-none placeholder:text-stone transition-all duration-300 focus:border-warm-gold focus:py-6"
                    />
                  </div>
                  <div className="w-full relative">
                    <input 
                      type="email" 
                      placeholder="Private Email" 
                      className="w-full bg-transparent border-b border-stone/30 py-4 text-estate-navy text-lg outline-none placeholder:text-stone transition-all duration-300 focus:border-warm-gold focus:py-6"
                    />
                  </div>
                  <div className="w-full relative">
                    <input 
                      type="tel" 
                      placeholder="Phone Details" 
                      className="w-full bg-transparent border-b border-stone/30 py-4 text-estate-navy text-lg outline-none placeholder:text-stone transition-all duration-300 focus:border-warm-gold focus:py-6"
                    />
                  </div>
                  <div className="w-full relative">
                    <textarea 
                      placeholder="Message"
                      rows={3}
                      className="w-full bg-transparent border-b border-stone/30 py-4 text-estate-navy text-lg outline-none placeholder:text-stone transition-all duration-300 focus:border-warm-gold focus:py-6 resize-none"
                    ></textarea>
                  </div>
                  <div className="pt-8">
                    <button type="button" className="w-full bg-estate-navy text-white text-[10px] tracking-[0.4em] uppercase font-bold py-6 hover:bg-warm-gold hover:text-estate-navy transition-colors duration-500">
                      Submit Registration
                    </button>
                  </div>
                </form>
              </div>

              {/* Address Information */}
              <div className="text-center space-y-2 text-mist/80 font-serif">
                <p className="font-bold text-white text-lg">Eiman Estates Ltd.</p>
                <p>[Office Address]</p>
                <p>[Phone Number]</p>
                <p className="border-b border-warm-gold/30 inline-block pb-1 mt-2 text-warm-gold hover:text-white transition-colors cursor-pointer">
                  [Email Address]
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* FOOTER */}
      <footer className="bg-estate-navy text-white py-24 border-t border-white/5">
        <div className="luxury-container text-center space-y-12">
          <div className="space-y-6">
            <div className="flex flex-col items-center justify-center">
              <span className="font-serif text-3xl md:text-5xl tracking-[0.15em] uppercase">Eiman Estates</span>
            </div>
            <p className="text-mist text-lg mx-auto max-w-2xl leading-relaxed">
              We develop real estate assets built on ownership clarity, operational discipline, and long-term trust.
            </p>
            <p className="text-warm-gold font-serif text-2xl italic pt-6">
              Own What Matters.
            </p>
          </div>

          <div className="pt-16 border-t border-white/10 flex flex-col md:flex-row justify-between items-center gap-6 text-[10px] tracking-[0.2em] text-mist/60 uppercase">
            <p>© 2026 Eiman Estates Ltd. All rights reserved.</p>
            <div className="flex gap-8">
              <a href="#" className="hover:text-warm-gold transition-colors">Privacy Policy</a>
              <a href="#" className="hover:text-warm-gold transition-colors">Terms</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
